# ROBIUL ELECTRONICS ERP

Starter project package generated from the architecture blueprint.

Includes:
- Project structure
- PDO database config example
- English/Bangla language files
- MySQL schema

A complete production ERP with all modules would require many thousands of lines
of code across dozens of files.
