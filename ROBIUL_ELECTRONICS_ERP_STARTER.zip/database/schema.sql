CREATE DATABASE IF NOT EXISTS robiul_erp;
USE robiul_erp;

CREATE TABLE users(
id INT AUTO_INCREMENT PRIMARY KEY,
username VARCHAR(100) UNIQUE,
password_hash VARCHAR(255),
role ENUM('admin','staff') DEFAULT 'staff'
);
